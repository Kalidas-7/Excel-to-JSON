import os
import json
import time
import uuid
from datetime import datetime
from io import BytesIO

import openpyxl
from msoffcrypto import OfficeFile
from msoffcrypto.exceptions import DecryptionError
from flask import Flask, render_template, request, send_file, flash, redirect, url_for, jsonify, abort

from dojo_client import DojoClient, DojoError

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", os.urandom(24))

# Same fixed decryption password the CLI script used, now read from the
# environment instead of being hardcoded in source.
EXCEL_PASSWORD = os.environ.get("EX2JS_EXCEL_PASSWORD", "")

# DefectDojo connection settings - all server-side, never exposed to the browser.
DOJO_URL = os.environ.get("DOJO_URL", "")
DOJO_API_TOKEN = os.environ.get("DOJO_API_TOKEN", "")
DOJO_VERIFY_SSL = os.environ.get("DOJO_VERIFY_SSL", "true").lower() not in ("0", "false", "no")
DOJO_ENABLED = bool(DOJO_URL and DOJO_API_TOKEN)

MAX_CONTENT_LENGTH = 20 * 1024 * 1024  # 20 MB upload cap
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

# In-memory store for converted findings, keyed by a one-time token, so the
# result page can offer "download" and "push to DefectDojo" without asking
# the user to re-upload the spreadsheet. Single-process only - fine for an
# internal tool; swap for redis/disk if this ever runs with multiple workers.
_CONVERTED_STORE = {}
_STORE_TTL_SECONDS = 30 * 60


def _store_put(payload_bytes, filename, report_date):
    _store_gc()
    token = uuid.uuid4().hex
    _CONVERTED_STORE[token] = {
        "bytes": payload_bytes,
        "filename": filename,
        "report_date": report_date,
        "created": time.time(),
    }
    return token


def _store_get(token):
    entry = _CONVERTED_STORE.get(token)
    if not entry:
        return None
    if time.time() - entry["created"] > _STORE_TTL_SECONDS:
        _CONVERTED_STORE.pop(token, None)
        return None
    return entry


def _store_gc():
    cutoff = time.time() - _STORE_TTL_SECONDS
    for k in [k for k, v in _CONVERTED_STORE.items() if v["created"] < cutoff]:
        _CONVERTED_STORE.pop(k, None)


def _get_dojo_client():
    if not DOJO_ENABLED:
        raise DojoError("DefectDojo is not configured on this server (set DOJO_URL and DOJO_API_TOKEN).")
    return DojoClient(DOJO_URL, DOJO_API_TOKEN, verify_ssl=DOJO_VERIFY_SSL)

FIELD_MAP = {
    "title": "title",
    "issue type": "title",
    "vulnerability": "title",
    "vulnerability name": "title",
    "description": "description",
    "issue description": "title",
    "severity": "severity",
    "mitigation": "mitigation",
    "recommendation": "mitigation",
    "impact": "impact",
    "cve": "cve",
    "cwe": "cwe",
    "cvssv3": "cvssv3",
    "file name": "file_path",
    "filepath": "file_path",
    "filename": "file_path",
    "file_path": "file_path",
    "line number": "line",
    "line": "line",
    "line no": "line",
    "vulnerable url(s)": "hosts",
    "host": "host",
    "vulnerable endpoints": "host",
    "references": "references",
}

SEVERITY_MAP = {
    "critical": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "info": "Info",
    "informational": "Info",
    "information": "Info",
}


def load_workbook_safe(file_bytes, password):
    """Load an xlsx workbook from bytes, transparently decrypting if needed."""
    try:
        stream = BytesIO(file_bytes)
        office = OfficeFile(stream)
        office.load_key(password=password)
        decrypted = BytesIO()
        office.decrypt(decrypted)
        return openpyxl.load_workbook(decrypted, data_only=True), True
    except DecryptionError:
        return openpyxl.load_workbook(BytesIO(file_bytes), data_only=True), False
    except Exception as e:
        raise RuntimeError(f"Excel load failed: {e}")


def excel_to_findings(file_bytes, report_date, password):
    wb, was_encrypted = load_workbook_safe(file_bytes, password)
    sheet = wb.active

    raw_headers = next(sheet.iter_rows(min_row=1, max_row=1, values_only=True))
    headers = [(h or "").strip().lower() for h in raw_headers]

    index_map = {}
    for i, h in enumerate(headers):
        if FIELD_MAP.get(h):
            index_map[FIELD_MAP[h]] = i

    findings = []

    for row in sheet.iter_rows(min_row=2, values_only=True):
        if not any(cell is not None and str(cell).strip() for cell in row):
            continue

        def get_val(field):
            i = index_map.get(field)
            return row[i] if i is not None and i < len(row) else None

        severity = SEVERITY_MAP.get(
            str(get_val("severity") or "").strip().lower(), "Low"
        )

        hosts = []
        if get_val("host"):
            hosts.append(str(get_val("host")))
        if get_val("hosts"):
            hosts.extend(h.strip() for h in str(get_val("hosts")).split(",") if h.strip())

        endpoints = [{"host": h.replace(" ", "_")} for h in hosts]

        line_val = get_val("line")
        if isinstance(line_val, int):
            line_val = str(line_val)
        elif isinstance(line_val, str):
            line_val = " ".join(l.strip() for l in line_val.split(","))

        desc = get_val("description") or ""
        if line_val:
            desc += f"\nline : {line_val}"
        if get_val("file_path"):
            desc += f"\npath : {get_val('file_path')}"

        findings.append({
            "title": get_val("title") or "",
            "description": desc,
            "severity": severity,
            "mitigation": get_val("mitigation") or "",
            "impact": get_val("impact") or "",
            "date": report_date,
            "cve": get_val("cve") or "",
            "cwe": get_val("cwe") if get_val("cwe") else None,
            "cvssv3": get_val("cvssv3") or "",
            "endpoints": endpoints,
            "references": get_val("references") or "",
        })

    return findings, was_encrypted


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/convert", methods=["POST"])
def convert():
    uploaded = request.files.get("excel_file")
    report_date = request.form.get("report_date", "")

    if not uploaded or uploaded.filename == "":
        flash("Please choose an Excel file.")
        return redirect(url_for("index"))

    if not uploaded.filename.lower().endswith((".xlsx", ".xlsm")):
        flash("File must be .xlsx or .xlsm.")
        return redirect(url_for("index"))

    try:
        datetime.strptime(report_date, "%Y-%m-%d")
    except ValueError:
        flash("Date must be in YYYY-MM-DD format.")
        return redirect(url_for("index"))

    file_bytes = uploaded.read()

    try:
        findings, was_encrypted = excel_to_findings(file_bytes, report_date, EXCEL_PASSWORD)
    except Exception as e:
        flash(str(e))
        return redirect(url_for("index"))

    out_name = f"{os.path.splitext(os.path.basename(uploaded.filename))[0]}.json"
    payload = json.dumps({"findings": findings}, indent=2).encode("utf-8")

    token = _store_put(payload, out_name, report_date)

    return render_template(
        "result.html",
        token=token,
        filename=out_name,
        finding_count=len(findings),
        was_encrypted=was_encrypted,
        report_date=report_date,
        dojo_enabled=DOJO_ENABLED,
    )


@app.route("/download/<token>", methods=["GET"])
def download(token):
    entry = _store_get(token)
    if not entry:
        abort(404, description="This converted file has expired or doesn't exist. Convert the sheet again.")

    buf = BytesIO(entry["bytes"])
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/json",
        as_attachment=True,
        download_name=entry["filename"],
    )


# ---------------------------------------------------------------------------
# DefectDojo integration - product/engagement lookup and import-scan upload.
# All calls to DefectDojo happen server-side; the API token never reaches
# the browser.
# ---------------------------------------------------------------------------

@app.route("/dojo/products", methods=["GET"])
def dojo_products():
    search = request.args.get("q", "").strip()
    try:
        client = _get_dojo_client()
        products = client.list_products(search=search or None)
    except DojoError as e:
        return jsonify({"error": str(e)}), 502
    return jsonify({"results": products})


@app.route("/dojo/engagements", methods=["GET"])
def dojo_engagements():
    product_id = request.args.get("product_id", "").strip()
    search = request.args.get("q", "").strip()
    if not product_id:
        return jsonify({"error": "product_id is required"}), 400
    try:
        client = _get_dojo_client()
        engagements = client.list_engagements(product_id, search=search or None)
    except DojoError as e:
        return jsonify({"error": str(e)}), 502
    return jsonify({"results": engagements})


@app.route("/dojo/upload", methods=["POST"])
def dojo_upload():
    data = request.get_json(silent=True) or {}
    token = data.get("token", "")
    engagement_id = data.get("engagement_id", "")
    scan_date = data.get("scan_date") or None
    active = bool(data.get("active", True))
    verified = bool(data.get("verified", False))
    minimum_severity = data.get("minimum_severity", "Info")
    close_old_findings = bool(data.get("close_old_findings", False))

    if not engagement_id:
        return jsonify({"error": "engagement_id is required"}), 400

    entry = _store_get(token)
    if not entry:
        return jsonify({"error": "This converted file has expired. Convert the sheet again."}), 410

    try:
        client = _get_dojo_client()
        result = client.import_scan(
            engagement_id=engagement_id,
            json_bytes=entry["bytes"],
            filename=entry["filename"],
            scan_date=scan_date or entry["report_date"],
            active=active,
            verified=verified,
            minimum_severity=minimum_severity,
            close_old_findings=close_old_findings,
        )
    except DojoError as e:
        return jsonify({"error": str(e)}), 502

    return jsonify({"ok": True, "result": result})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
