"""Minimal DefectDojo API v2 client for pushing Generic Findings Import JSON."""
import requests


class DojoError(Exception):
    pass


class DojoClient:
    def __init__(self, base_url, api_token, verify_ssl=True, timeout=15):
        if not base_url or not api_token:
            raise DojoError("DefectDojo is not configured (missing URL or API token).")
        self.base_url = base_url.rstrip("/")
        self.headers = {"Authorization": f"Token {api_token}"}
        self.verify_ssl = verify_ssl
        self.timeout = timeout

    def _get(self, path, params=None):
        try:
            resp = requests.get(
                f"{self.base_url}{path}",
                headers=self.headers,
                params=params,
                verify=self.verify_ssl,
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise DojoError(f"Could not reach DefectDojo: {e}") from e
        if not resp.ok:
            raise DojoError(f"GET {path} failed: {resp.status_code} {resp.text[:300]}")
        return resp.json()

    def list_products(self, search=None, limit=100):
        params = {"limit": limit, "o": "name"}
        if search:
            # Attempt server-side filtering; harmless if the deployment ignores it.
            params["name__icontains"] = search
        data = self._get("/api/v2/products/", params=params)
        results = [{"id": p["id"], "name": p["name"]} for p in data.get("results", [])]
        if search:
            s = search.lower()
            results = [r for r in results if s in r["name"].lower()]
        return results

    def list_engagements(self, product_id, search=None, limit=100):
        params = {"product": product_id, "limit": limit, "o": "-created"}
        if search:
            params["name__icontains"] = search
        data = self._get("/api/v2/engagements/", params=params)
        results = [
            {"id": e["id"], "name": e["name"], "active": e.get("active", True)}
            for e in data.get("results", [])
        ]
        if search:
            s = search.lower()
            results = [r for r in results if s in r["name"].lower()]
        return results

    def import_scan(
        self,
        engagement_id,
        json_bytes,
        filename,
        scan_date=None,
        active=True,
        verified=False,
        minimum_severity="Info",
        close_old_findings=False,
    ):
        data = {
            "scan_type": "Generic Findings Import",
            "engagement": str(engagement_id),
            "active": "true" if active else "false",
            "verified": "true" if verified else "false",
            "minimum_severity": minimum_severity,
            "close_old_findings": "true" if close_old_findings else "false",
        }
        if scan_date:
            data["scan_date"] = scan_date

        files = {"file": (filename, json_bytes, "application/json")}
        try:
            resp = requests.post(
                f"{self.base_url}/api/v2/import-scan/",
                headers=self.headers,
                data=data,
                files=files,
                verify=self.verify_ssl,
                timeout=60,
            )
        except requests.RequestException as e:
            raise DojoError(f"Could not reach DefectDojo: {e}") from e

        if not resp.ok:
            raise DojoError(f"Import failed: {resp.status_code} {resp.text[:500]}")
        return resp.json()
